'use client';

import { CheckIcon } from 'lucide-react';

interface FeatureListProps {
  features: string[];
  className?: string;
}

export default function FeatureList({ features, className = '' }: FeatureListProps) {
  return (
    <ul className={`space-y-3 ${className}`}>
      {features.map((feature, index) => (
        <li key={index} className="flex items-start">
          <CheckIcon className="h-5 w-5 text-[#00A52E] flex-shrink-0 mr-2" />
          <span className="text-white">{feature}</span>
        </li>
      ))}
    </ul>
  );
}
