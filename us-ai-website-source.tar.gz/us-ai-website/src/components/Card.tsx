'use client';

interface CardProps {
  title?: string;
  className?: string;
  children: React.ReactNode;
  gradient?: boolean;
}

export default function Card({ 
  title, 
  className = '', 
  children,
  gradient = false
}: CardProps) {
  return (
    <div className={`card ${gradient ? 'gradient-border' : ''} ${className}`}>
      {title && <h3 className="text-xl font-bold mb-4 gradient-text">{title}</h3>}
      {children}
    </div>
  );
}
