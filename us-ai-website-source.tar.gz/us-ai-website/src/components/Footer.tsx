export default function Footer() {
  return (
    <footer className="bg-[#191970] border-t border-[#0cef4e]/20 py-8 px-6 md:px-12">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-[#00A52E] font-bold text-xl mb-4">Us+AI</h3>
            <p className="text-white text-sm">
              Enhancing guest experiences, streamlining operations, and boosting revenue with our specialized AI agents for hospitality businesses.
            </p>
          </div>
          
          <div>
            <h3 className="text-[#00A52E] font-bold text-xl mb-4">Services</h3>
            <ul className="space-y-2">
              <li><a href="/services#hotel" className="text-white hover:text-[#0cef4e] text-sm transition-colors">Hotel AI Concierge</a></li>
              <li><a href="/services#restaurant" className="text-white hover:text-[#0cef4e] text-sm transition-colors">Restaurant AI Management</a></li>
              <li><a href="/services#culinary" className="text-white hover:text-[#0cef4e] text-sm transition-colors">Culinary AI Communication</a></li>
              <li><a href="/services#conference" className="text-white hover:text-[#0cef4e] text-sm transition-colors">Conference AI Solutions</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-[#00A52E] font-bold text-xl mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="/about" className="text-white hover:text-[#0cef4e] text-sm transition-colors">About Us</a></li>
              <li><a href="/about#team" className="text-white hover:text-[#0cef4e] text-sm transition-colors">Meet the Minds</a></li>
              <li><a href="/pricing" className="text-white hover:text-[#0cef4e] text-sm transition-colors">Pricing</a></li>
              <li><a href="/contact" className="text-white hover:text-[#0cef4e] text-sm transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-[#00A52E] font-bold text-xl mb-4">Contact</h3>
            <p className="text-white text-sm mb-2">Get in touch with us</p>
            <a href="mailto:earth@urbanseed.net" className="text-[#0cef4e] hover:underline text-sm">earth@urbanseed.net</a>
          </div>
        </div>
        
        <div className="border-t border-[#0cef4e]/20 mt-8 pt-8 text-center">
          <p className="text-white text-sm">
            &copy; {new Date().getFullYear()} Us+AI. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
