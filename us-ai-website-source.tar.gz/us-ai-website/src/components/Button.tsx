'use client';

import { ReactNode } from 'react';

interface ButtonProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  onClick?: () => void;
}

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  onClick,
}: ButtonProps) {
  const baseClasses = 'inline-flex items-center justify-center font-medium transition-all focus:outline-none';
  
  const variantClasses = {
    primary: 'glossy-button',
    secondary: 'bg-[#191970] text-white border border-[#00A52E] hover:bg-[#00A52E]/10',
    outline: 'bg-transparent text-[#00A52E] border border-[#00A52E] hover:bg-[#00A52E]/10',
  };
  
  const sizeClasses = {
    sm: 'text-sm px-3 py-1.5 rounded',
    md: 'text-base px-4 py-2 rounded-md',
    lg: 'text-lg px-6 py-3 rounded-lg',
  };
  
  return (
    <button
      className={`${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
