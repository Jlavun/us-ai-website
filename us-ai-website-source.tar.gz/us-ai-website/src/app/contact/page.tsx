'use client';

import { useState } from 'react';
import Layout from '@/components/Layout';
import Button from '@/components/Button';
import Card from '@/components/Card';

export default function Contact() {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    message: '',
    service: 'hotel',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormState(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      
      // Reset form after submission
      setFormState({
        name: '',
        email: '',
        company: '',
        phone: '',
        message: '',
        service: 'hotel',
      });
    }, 1500);
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-20 bg-[#191970]/90">
        <div className="container mx-auto px-6 md:px-12">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="text-white">Contact </span>
              <span className="gradient-text">Us</span>
            </h1>
            <p className="text-white text-xl mb-8">
              Get in touch to learn how our AI solutions can transform your hospitality business
            </p>
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section className="py-20">
        <div className="container mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold mb-6">
                <span className="gradient-text">Get in Touch</span>
              </h2>
              <p className="text-white mb-8">
                We're excited to hear from you and learn more about your hospitality business. Fill out the form and our team will get back to you as soon as possible to discuss how our AI solutions can help you enhance guest experiences and streamline operations.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-[#00A52E]/20 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00A52E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-1">Email</h3>
                    <a href="mailto:earth@urbanseed.net" className="text-[#00A52E] hover:underline">earth@urbanseed.net</a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-[#00A52E]/20 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00A52E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-1">Response Time</h3>
                    <p className="text-white">We typically respond within 24 hours</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <Card gradient className="p-8">
                {isSubmitted ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-[#00A52E]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#00A52E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <h3 className="text-2xl font-bold mb-4 text-white">Message Sent!</h3>
                    <p className="text-white mb-6">
                      Thank you for reaching out. Our team will get back to you as soon as possible.
                    </p>
                    <Button onClick={() => setIsSubmitted(false)}>Send Another Message</Button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit}>
                    <div className="mb-6">
                      <label htmlFor="name" className="block text-white mb-2">Full Name</label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formState.name}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 rounded bg-[#191970] border border-[#00A52E]/30 text-white focus:border-[#00A52E] focus:outline-none"
                      />
                    </div>
                    
                    <div className="mb-6">
                      <label htmlFor="email" className="block text-white mb-2">Email Address</label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formState.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 rounded bg-[#191970] border border-[#00A52E]/30 text-white focus:border-[#00A52E] focus:outline-none"
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <label htmlFor="company" className="block text-white mb-2">Company Name</label>
                        <input
                          type="text"
                          id="company"
                          name="company"
                          value={formState.company}
                          onChange={handleChange}
                          className="w-full px-4 py-2 rounded bg-[#191970] border border-[#00A52E]/30 text-white focus:border-[#00A52E] focus:outline-none"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="phone" className="block text-white mb-2">Phone Number</label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={formState.phone}
                          onChange={handleChange}
                          className="w-full px-4 py-2 rounded bg-[#191970] border border-[#00A52E]/30 text-white focus:border-[#00A52E] focus:outline-none"
                        />
                      </div>
                    </div>
                    
                    <div className="mb-6">
                      <label htmlFor="service" className="block text-white mb-2">Interested Service</label>
                      <select
                        id="service"
                        name="service"
                        value={formState.service}
                        onChange={handleChange}
                        className="w-full px-4 py-2 rounded bg-[#191970] border border-[#00A52E]/30 text-white focus:border-[#00A52E] focus:outline-none"
                      >
                        <option value="hotel">Hotel AI Concierge</option>
                        <option value="restaurant">Restaurant AI Management</option>
                        <option value="culinary">Culinary AI Communication</option>
                        <option value="conference">Conference AI Solutions</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    
                    <div className="mb-6">
                      <label htmlFor="message" className="block text-white mb-2">Message</label>
                      <textarea
                        id="message"
                        name="message"
                        value={formState.message}
                        onChange={handleChange}
                        required
                        rows={5}
                        className="w-full px-4 py-2 rounded bg-[#191970] border border-[#00A52E]/30 text-white focus:border-[#00A52E] focus:outline-none"
                      ></textarea>
                    </div>
                    
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? 'Sending...' : 'Send Message'}
                    </Button>
                  </form>
                )}
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-20 bg-[#191970]/80">
        <div className="container mx-auto px-6 md:px-12">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="gradient-text">Ready to Transform Your Hospitality Business?</span>
            </h2>
            <p className="text-white text-lg max-w-3xl mx-auto">
              Schedule a demo to see our AI solutions in action and discover how they can enhance your guest experiences.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <Card gradient className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-6 text-white">Schedule a Demo</h3>
              <p className="text-white mb-8">
                See our AI solutions in action and discover how they can transform your hospitality business.
              </p>
              <Button size="lg">Request Demo</Button>
            </Card>
          </div>
        </div>
      </section>
    </Layout>
  );
}
