'use client';

import Layout from '@/components/Layout';
import Card from '@/components/Card';
import Button from '@/components/Button';
import FeatureList from '@/components/FeatureList';

export default function Pricing() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-20 bg-[#191970]/90">
        <div className="container mx-auto px-6 md:px-12">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="text-white">Flexible </span>
              <span className="gradient-text">Pricing Plans</span>
            </h1>
            <p className="text-white text-xl mb-8">
              Choose the perfect plan for your hospitality business needs, from individual services to comprehensive AI solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Toggle */}
      <section className="py-12">
        <div className="container mx-auto px-6 md:px-12">
          <div className="flex justify-center mb-12">
            <div className="inline-flex rounded-md p-1 bg-[#191970] border border-[#00A52E]/30">
              <button className="px-6 py-2 rounded text-white bg-[#00A52E]">Monthly Billing</button>
              <button className="px-6 py-2 rounded text-white">Annual Billing</button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Pay Per Service */}
            <div className="pricing-card relative">
              <Card gradient className="p-8 h-full flex flex-col">
                <h3 className="text-2xl font-bold mb-2 text-white">Pay Per Service</h3>
                <p className="text-white/80 mb-6">
                  Perfect for businesses looking to try specific AI services without a long-term commitment.
                </p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">$99</span>
                  <span className="text-white/80">/per month</span>
                </div>
                <div className="mb-8">
                  <h4 className="text-[#00A52E] font-semibold mb-3">Features:</h4>
                  <FeatureList 
                    features={[
                      "Access to individual AI services",
                      "Pay only for what you use",
                      "No long-term commitment",
                      "24/7 email support"
                    ]}
                  />
                </div>
                <div className="mt-auto">
                  <Button className="w-full">Get Started</Button>
                </div>
              </Card>
            </div>

            {/* Maintain & Update */}
            <div className="pricing-card relative mt-8 md:mt-0">
              <div className="absolute -top-4 left-0 right-0 flex justify-center">
                <span className="popular-badge">Most Popular</span>
              </div>
              <Card gradient className="p-8 h-full flex flex-col border-2 border-[#00A52E]">
                <h3 className="text-2xl font-bold mb-2 text-white">Maintain & Update</h3>
                <p className="text-white/80 mb-6">
                  Ideal for established businesses looking to maintain and regularly update their AI solutions.
                </p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">$499</span>
                  <span className="text-white/80">/per month</span>
                </div>
                <div className="mb-8">
                  <h4 className="text-[#00A52E] font-semibold mb-3">Features:</h4>
                  <FeatureList 
                    features={[
                      "All Pay Per Service features",
                      "Monthly system updates",
                      "Integration with existing systems",
                      "Priority support response"
                    ]}
                  />
                </div>
                <div className="mt-auto">
                  <Button className="w-full">Get Started</Button>
                </div>
              </Card>
            </div>

            {/* Full Implementation */}
            <div className="pricing-card relative">
              <Card gradient className="p-8 h-full flex flex-col">
                <h3 className="text-2xl font-bold mb-2 text-white">Full Implementation</h3>
                <p className="text-white/80 mb-6">
                  Comprehensive solution for businesses seeking complete AI transformation and ongoing support.
                </p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">$1,299</span>
                  <span className="text-white/80">/per month</span>
                </div>
                <div className="mb-8">
                  <h4 className="text-[#00A52E] font-semibold mb-3">Features:</h4>
                  <FeatureList 
                    features={[
                      "All Maintain & Update features",
                      "Custom AI agent development",
                      "Full system implementation",
                      "Dedicated account manager",
                      "24/7 priority support"
                    ]}
                  />
                </div>
                <div className="mt-auto">
                  <Button className="w-full">Get Started</Button>
                </div>
              </Card>
            </div>
          </div>

          <div className="text-center mt-12">
            <p className="text-white text-lg">
              All pricing is customized based on your specific business needs. 
              <br />Contact us for a personalized quote.
            </p>
          </div>
        </div>
      </section>

      {/* Enterprise Section */}
      <section className="py-20 bg-[#191970]/80">
        <div className="container mx-auto px-6 md:px-12">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6">
                  <span className="gradient-text">Enterprise Solutions</span>
                </h2>
                <p className="text-white mb-6">
                  For large hospitality groups and chains requiring custom AI solutions across multiple properties or concepts.
                </p>
                <FeatureList 
                  features={[
                    "Custom AI development for specific business needs",
                    "Multi-property implementation and management",
                    "Integration with existing enterprise systems",
                    "Dedicated development and support team",
                    "Regular strategy meetings and roadmap planning",
                    "Custom analytics and reporting"
                  ]}
                  className="mb-8"
                />
                <Button>Contact Sales</Button>
              </div>
              <Card gradient className="p-6">
                <h3 className="text-xl font-bold mb-4 text-white">Custom Quote</h3>
                <p className="text-white mb-6">
                  Our enterprise solutions are tailored to your specific requirements and scale. Contact our sales team for a personalized consultation and quote.
                </p>
                <div className="flex items-center justify-center p-6 bg-[#191970]/50 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-[#00A52E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                  </svg>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container mx-auto px-6 md:px-12">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Frequently Asked </span>
              <span className="gradient-text">Questions</span>
            </h2>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <div className="space-y-6">
              <Card className="p-6">
                <h3 className="text-xl font-bold mb-3 text-white">Can I customize my plan based on my business needs?</h3>
                <p className="text-white">
                  Yes, all our pricing plans can be customized based on your specific business requirements. Contact our sales team for a personalized quote.
                </p>
              </Card>
              
              <Card className="p-6">
                <h3 className="text-xl font-bold mb-3 text-white">Is there a contract or minimum commitment period?</h3>
                <p className="text-white">
                  Our Pay Per Service plan has no long-term commitment. Maintain & Update and Full Implementation plans typically have a 3-month minimum term, but this can be adjusted based on your needs.
                </p>
              </Card>
              
              <Card className="p-6">
                <h3 className="text-xl font-bold mb-3 text-white">What kind of support is included in each plan?</h3>
                <p className="text-white">
                  All plans include email support. Maintain & Update includes priority response times, while Full Implementation includes 24/7 priority support and a dedicated account manager.
                </p>
              </Card>
              
              <Card className="p-6">
                <h3 className="text-xl font-bold mb-3 text-white">Can I upgrade my plan as my business grows?</h3>
                <p className="text-white">
                  Absolutely! You can upgrade your plan at any time as your business needs evolve. Our team will ensure a smooth transition between plans.
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-[#191970]/80">
        <div className="container mx-auto px-6 md:px-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">Ready to Get Started?</span>
          </h2>
          <p className="text-white text-lg max-w-3xl mx-auto mb-8">
            Contact us today to discuss your hospitality business needs and find the perfect AI solution.
          </p>
          <Button size="lg">Contact Us Today</Button>
        </div>
      </section>
    </Layout>
  );
}
