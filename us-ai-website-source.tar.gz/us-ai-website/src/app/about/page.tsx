'use client';

import Layout from '@/components/Layout';
import Card from '@/components/Card';
import Button from '@/components/Button';

export default function About() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-20 bg-[#191970]/90">
        <div className="container mx-auto px-6 md:px-12">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="text-white">About </span>
              <span className="gradient-text">Us+AI</span>
            </h1>
            <p className="text-white text-xl mb-8">
              Pioneering AI solutions for the hospitality industry to enhance guest experiences and streamline operations.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20">
        <div className="container mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">
                <span className="gradient-text">Our Story</span>
              </h2>
              <p className="text-white mb-4">
                Us+AI was founded with a clear vision: to revolutionize the hospitality industry through cutting-edge artificial intelligence solutions. We recognized that time is the most precious resource for both businesses and their customers, and our mission became to create AI agents that could save time while enhancing experiences.
              </p>
              <p className="text-white mb-4">
                Our team of AI specialists, hospitality experts, and technology innovators came together to develop specialized AI agents designed specifically for restaurants, hotels, and culinary concepts. We understand the unique challenges faced by the hospitality industry and have crafted our solutions to address these specific needs.
              </p>
              <p className="text-white">
                Today, Us+AI is at the forefront of hospitality innovation, providing AI solutions that not only automate routine tasks but also enhance the human touch that makes hospitality special.
              </p>
            </div>
            <div className="gradient-border p-1">
              <div className="bg-[#191970] p-8">
                <h3 className="text-2xl font-bold mb-4 text-[#00A52E]">Our Mission</h3>
                <p className="text-white mb-6">
                  To empower hospitality businesses with AI solutions that save time, enhance guest experiences, and drive business growth.
                </p>
                <h3 className="text-2xl font-bold mb-4 text-[#00A52E]">Our Vision</h3>
                <p className="text-white">
                  A hospitality industry where AI seamlessly integrates with human service to create exceptional experiences for guests and sustainable success for businesses.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Philosophy Section */}
      <section className="py-20 bg-[#191970]/80">
        <div className="container mx-auto px-6 md:px-12">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="gradient-text">Our Philosophy</span>
            </h2>
            <p className="text-white text-lg max-w-3xl mx-auto">
              We believe in creating AI solutions that enhance rather than replace the human touch in hospitality.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-6 text-center">
              <div className="w-16 h-16 bg-[#00A52E]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#00A52E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-4 text-white">Time-Saving Innovation</h3>
              <p className="text-white">
                We develop AI solutions that automate routine tasks, allowing hospitality staff to focus on creating memorable guest experiences.
              </p>
            </Card>
            
            <Card className="p-6 text-center">
              <div className="w-16 h-16 bg-[#00A52E]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#00A52E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-4 text-white">Human-Centered Design</h3>
              <p className="text-white">
                Our AI solutions are designed to complement human service, not replace it, enhancing the personal touch that makes hospitality special.
              </p>
            </Card>
            
            <Card className="p-6 text-center">
              <div className="w-16 h-16 bg-[#00A52E]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#00A52E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-4 text-white">Industry-Specific Solutions</h3>
              <p className="text-white">
                We create specialized AI agents tailored to the unique needs of restaurants, hotels, and culinary concepts, not generic AI tools.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Meet the Minds Section (Placeholder) */}
      <section className="py-20">
        <div className="container mx-auto px-6 md:px-12">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Meet the </span>
              <span className="gradient-text">Minds</span>
            </h2>
            <p className="text-white text-lg max-w-3xl mx-auto">
              Our team of AI specialists, hospitality experts, and technology innovators working together to revolutionize the hospitality industry.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Team member placeholders - to be filled later */}
            {[1, 2, 3].map((item) => (
              <Card key={item} className="p-6 text-center">
                <div className="w-32 h-32 bg-[#00A52E]/20 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-[#00A52E]/50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2 text-white">Team Member</h3>
                <p className="text-[#00A52E] mb-4">Position</p>
                <p className="text-white text-sm">
                  Bio information will be added later.
                </p>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <p className="text-white italic">
              Team photos and detailed bios will be added in the future.
            </p>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-[#191970]/80">
        <div className="container mx-auto px-6 md:px-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">Ready to Transform Your Hospitality Business?</span>
          </h2>
          <p className="text-white text-lg max-w-3xl mx-auto mb-8">
            Contact us today to learn how our AI solutions can enhance your guest experiences and streamline your operations.
          </p>
          <Button size="lg">Contact Us Today</Button>
        </div>
      </section>
    </Layout>
  );
}
