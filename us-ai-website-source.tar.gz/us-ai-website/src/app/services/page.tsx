'use client';

import { useState } from 'react';
import Layout from '@/components/Layout';
import Card from '@/components/Card';
import Button from '@/components/Button';
import AudioPlayer from '@/components/AudioPlayer';
import FeatureList from '@/components/FeatureList';

export default function Services() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-20 bg-[#191970]/90">
        <div className="container mx-auto px-6 md:px-12">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="text-white">Our </span>
              <span className="gradient-text">Services</span>
            </h1>
            <p className="text-white text-xl mb-8">
              Specialized AI solutions designed to transform the hospitality industry
            </p>
          </div>
        </div>
      </section>

      {/* Hotel AI Concierge Section */}
      <section id="hotel" className="py-20">
        <div className="container mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">
                <span className="gradient-text">Boutique Hotel AI Concierge</span>
              </h2>
              <p className="text-white mb-6">
                Our AI Concierge transforms the guest experience at boutique hotels by providing personalized, 24/7 service. From check-in to check-out, our AI solution ensures every guest interaction is seamless and memorable.
              </p>
              <FeatureList 
                features={[
                  "24/7 virtual concierge service available through multiple channels",
                  "Personalized guest recommendations based on preferences and past stays",
                  "Automated check-in and check-out processes to reduce wait times",
                  "Room service and housekeeping management with real-time updates",
                  "Multi-language support for international guests",
                  "Integration with existing hotel management systems"
                ]}
                className="mb-8"
              />
              <Button>Request Demo</Button>
            </div>
            <div>
              <Card gradient className="p-6">
                <h3 className="text-xl font-bold mb-4 text-white">Listen to Jay, our Hotel AI Concierge</h3>
                <p className="text-white mb-6">
                  Experience how our AI Concierge interacts with hotel guests, providing personalized recommendations and assistance.
                </p>
                <AudioPlayer 
                  src="/assets/audio/hotel_concierge.wav" 
                  title="Jay: AI Concierge for Boutique Hotel Guest Experience"
                />
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Restaurant AI Management Section */}
      <section id="restaurant" className="py-20 bg-[#191970]/80">
        <div className="container mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <Card gradient className="p-6">
                <h3 className="text-xl font-bold mb-4 text-white">Listen to our Restaurant Operations AI</h3>
                <p className="text-white mb-6">
                  Hear how our AI solution streamlines restaurant operations, manages inventory, and enhances customer service.
                </p>
                <AudioPlayer 
                  src="/assets/audio/restaurant_operations.wav" 
                  title="The Grid Food Market: AI-Powered Operations"
                />
              </Card>
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl font-bold mb-6">
                <span className="gradient-text">Restaurant AI Management</span>
              </h2>
              <p className="text-white mb-6">
                Our Restaurant AI Management system revolutionizes how restaurants operate by streamlining processes, optimizing inventory, and enhancing customer service, allowing staff to focus on creating exceptional dining experiences.
              </p>
              <FeatureList 
                features={[
                  "Automated reservation management and table optimization",
                  "Inventory tracking, ordering suggestions, and waste reduction",
                  "Staff scheduling based on historical demand patterns",
                  "Customer preference tracking for personalized service",
                  "Menu optimization based on popularity and profitability",
                  "Performance analytics with actionable insights"
                ]}
                className="mb-8"
              />
              <Button>Request Demo</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Culinary AI Communication Section */}
      <section id="culinary" className="py-20">
        <div className="container mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">
                <span className="gradient-text">Culinary Concept AI Communication</span>
              </h2>
              <p className="text-white mb-6">
                Our Culinary Concept AI Communication tools help food-focused businesses enhance their brand presence, engage with customers more effectively, and analyze feedback to continuously improve their offerings.
              </p>
              <FeatureList 
                features={[
                  "AI-generated social media content tailored to your culinary brand",
                  "Customer feedback analysis with sentiment tracking",
                  "Personalized email marketing campaigns based on customer preferences",
                  "Recipe and menu content creation with SEO optimization",
                  "Trend analysis and forecasting for menu planning",
                  "Competitive analysis and market positioning insights"
                ]}
                className="mb-8"
              />
              <Button>Request Demo</Button>
            </div>
            <div>
              <Card gradient className="p-6">
                <h3 className="text-xl font-bold mb-4 text-white">Culinary AI Communication</h3>
                <p className="text-white mb-6">
                  Our AI communication tools help culinary businesses enhance their brand presence, engage with customers more effectively, and analyze feedback to continuously improve.
                </p>
                <div className="aspect-w-16 aspect-h-9 bg-[#00A52E]/10 rounded-lg flex items-center justify-center">
                  <div className="text-center p-6">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-[#00A52E] mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                    <p className="text-white">Audio demonstration coming soon</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Conference AI Solutions Section */}
      <section id="conference" className="py-20 bg-[#191970]/80">
        <div className="container mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <Card gradient className="p-6">
                <h3 className="text-xl font-bold mb-4 text-white">Conference AI Solutions</h3>
                <p className="text-white mb-6">
                  Our AI solutions for conferences and events help organizers create seamless experiences for attendees while streamlining planning and execution processes.
                </p>
                <div className="aspect-w-16 aspect-h-9 bg-[#00A52E]/10 rounded-lg flex items-center justify-center">
                  <div className="text-center p-6">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-[#00A52E] mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    <p className="text-white">Audio demonstration coming soon</p>
                  </div>
                </div>
              </Card>
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl font-bold mb-6">
                <span className="gradient-text">Conference AI Solutions</span>
              </h2>
              <p className="text-white mb-6">
                Our Conference AI Solutions transform how events are planned, executed, and experienced. From attendee engagement to speaker management, our AI tools ensure every aspect of your conference runs smoothly.
              </p>
              <FeatureList 
                features={[
                  "AI-powered attendee registration and check-in",
                  "Personalized agenda recommendations for attendees",
                  "Real-time Q&A and polling during sessions",
                  "Speaker management and scheduling optimization",
                  "Post-event feedback analysis and insights",
                  "Virtual attendee engagement for hybrid events"
                ]}
                className="mb-8"
              />
              <Button>Request Demo</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20">
        <div className="container mx-auto px-6 md:px-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">Ready to Transform Your Hospitality Business?</span>
          </h2>
          <p className="text-white text-lg max-w-3xl mx-auto mb-8">
            Contact us today to learn how our AI solutions can enhance your guest experiences and streamline your operations.
          </p>
          <Button size="lg">Contact Us Today</Button>
        </div>
      </section>
    </Layout>
  );
}
