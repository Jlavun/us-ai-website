'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import Button from '@/components/Button';
import Card from '@/components/Card';
import FeatureList from '@/components/FeatureList';
import Layout from '@/components/Layout';

export default function Home() {
  const [videoLoaded, setVideoLoaded] = useState(false);

  useEffect(() => {
    // Ensure video loads properly
    const timer = setTimeout(() => {
      setVideoLoaded(true);
    }, 500);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="hero-section relative h-screen flex items-center">
        <video 
          className="hero-video"
          autoPlay 
          muted 
          loop 
          playsInline
        >
          <source src="/assets/videos/promo.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        
        <div className="container mx-auto px-6 md:px-12 hero-content">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              <span className="text-white">AI-Powered Solutions for the </span>
              <span className="gradient-text">Hospitality Industry</span>
            </h1>
            <p className="text-white text-xl mb-8">
              Enhance guest experiences, streamline operations, and boost revenue with our specialized AI agents for restaurants, hotels, and culinary concepts.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg">Get Started</Button>
              <Button variant="outline" size="lg">View Demo</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Promotional Video Section */}
      <section className="py-20 bg-[#191970]/80">
        <div className="container mx-auto px-6 md:px-12">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="gradient-text">Time is the Most Precious Resource</span>
            </h2>
            <p className="text-white text-lg max-w-3xl mx-auto">
              Our AI solutions help you reclaim valuable time by automating routine tasks and enhancing customer interactions.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto gradient-border p-1">
            <div className="aspect-w-16 aspect-h-9 relative">
              {videoLoaded && (
                <video 
                  controls 
                  className="w-full h-full object-cover"
                >
                  <source src="/assets/videos/promo.mp4" type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview Section */}
      <section className="py-20">
        <div className="container mx-auto px-6 md:px-12">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Our </span>
              <span className="gradient-text">AI Solutions</span>
            </h2>
            <p className="text-white text-lg max-w-3xl mx-auto">
              Specialized AI agents designed specifically for the hospitality industry
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Restaurant AI Management */}
            <Card gradient className="p-6">
              <h3 className="text-2xl font-bold mb-4 text-white">Restaurant AI Management</h3>
              <p className="text-white mb-6">
                Streamline operations, optimize staffing, manage inventory, and enhance customer service with our AI management system for restaurants.
              </p>
              <FeatureList 
                features={[
                  "Automated reservation management",
                  "Inventory optimization and waste reduction",
                  "Staff scheduling and performance analytics",
                  "Customer preference tracking",
                  "Menu optimization based on sales data"
                ]}
                className="mb-6"
              />
              <Button className="w-full">Learn More</Button>
            </Card>
            
            {/* Boutique Hotel AI Concierge */}
            <Card gradient className="p-6">
              <h3 className="text-2xl font-bold mb-4 text-white">Boutique Hotel AI Concierge</h3>
              <p className="text-white mb-6">
                Provide personalized guest experiences, streamline check-in/out processes, and offer 24/7 virtual concierge services with our AI solution.
              </p>
              <FeatureList 
                features={[
                  "24/7 virtual concierge service",
                  "Personalized guest recommendations",
                  "Automated check-in and check-out",
                  "Room service and housekeeping management",
                  "Multi-language support"
                ]}
                className="mb-6"
              />
              <Button className="w-full">Learn More</Button>
            </Card>
            
            {/* Culinary Concept AI Communication */}
            <Card gradient className="p-6">
              <h3 className="text-2xl font-bold mb-4 text-white">Culinary Concept AI Communication</h3>
              <p className="text-white mb-6">
                Enhance your culinary brand with AI-powered communication tools for marketing, customer engagement, and feedback analysis.
              </p>
              <FeatureList 
                features={[
                  "Social media content generation",
                  "Customer feedback analysis",
                  "Personalized email marketing",
                  "Recipe and menu content creation",
                  "Trend analysis and forecasting"
                ]}
                className="mb-6"
              />
              <Button className="w-full">Learn More</Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 bg-[#191970]/80">
        <div className="container mx-auto px-6 md:px-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">Ready to Transform Your Hospitality Business?</span>
          </h2>
          <p className="text-white text-lg max-w-3xl mx-auto mb-8">
            Join the leading hospitality brands already using our AI solutions to enhance guest experiences and streamline operations.
          </p>
          <Button size="lg">Contact Us Today</Button>
        </div>
      </section>
    </Layout>
  );
}
